# bilkent_traffic
An automated approach to interact with official Bilkent Traffic center.
